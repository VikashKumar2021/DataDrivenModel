package com.w2a.testcases;


import java.util.Hashtable;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.w2a.base.BaseClass;
import com.w2a.utilities.ReadExcelUtility;
import com.w2a.utilities.TestUtilities;


public class AddCustomerTest extends BaseClass {

	@Test(dataProviderClass= TestUtilities.class, dataProvider = "dp")
	public void addCustomerTest(Hashtable<String,String> data) {
		// String firstName, String lastName, String postCode, String alertText, String runMode
		if(!(data.get("runMode").equalsIgnoreCase("Y"))) {
			throw new  SkipException("Skipping the test case as the data is set as NO!!");
		}
			if (!(TestUtilities.isTestRunnable("addCustomerTest", excel))) {

			throw new SkipException("Skipping the test " + "addCustomerTest".toUpperCase() + "as the Run mode is NO");
		}
		
		log.debug("Inside the test method: " +new Throwable().getStackTrace()[0].getMethodName());
		click("addCutomerTab_CSS"); 
		type("firstName_CSS", data.get("firstName"));
		type("lastName_CSS", data.get("lastName"));
		type("postCode_CSS", data.get("postCode"));
		click("addCustomerSubmitButton_CSS");
		
		log.debug("Sbumitting the form!!");
		
			//Alert alert= driver.switchTo().alert();
			Alert alert =wait.until(ExpectedConditions.alertIsPresent());
			
			Assert.assertTrue(alert.getText().contains(data.get("alertText")));
			log.debug("Application is submitted successfully with alert message :"+alert.getText());
			alert.accept();
			log.debug("Moving out of the test method: " +new Throwable().getStackTrace()[0].getMethodName());
			Reporter.log("Test method " + new Throwable().getStackTrace()[0].getMethodName()+" is executed successfully");
			
		
	}

	

}
