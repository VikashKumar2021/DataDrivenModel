package com.w2a.testcases;

import java.util.Hashtable;

import org.openqa.selenium.Alert;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.Test;

import com.w2a.base.BaseClass;
import com.w2a.utilities.TestUtilities;

public class OpenAccountTest extends BaseClass {
	@Test(dataProviderClass = TestUtilities.class, dataProvider = "dp")
	public void openAccountTest(Hashtable<String, String> data) {
  //String customerName, String currency, String alertText
		if (!(TestUtilities.isTestRunnable("openAccountTest", excel))) {

			throw new SkipException("Skipping the test " + "openAccountTest".toUpperCase() + "as the Run mode is NO");
		}

		log.debug("Inside the test method: " + new Throwable().getStackTrace()[0].getMethodName());
		click("openAccountTab_XPATH");
		select("customerDropdown_ID",  data.get("customerName"));
		select("currencyDropdown_ID", data.get("currency"));
		click("processButton_XPATH");

		log.debug("Sbumitting the form!!");

		// Alert alert= driver.switchTo().alert();
		Alert alert = wait.until(ExpectedConditions.alertIsPresent());

		Assert.assertTrue(alert.getText().contains(data.get("alertText")));
		log.debug("Application is submitted successfully with alert message :" + alert.getText());
		alert.accept();
		log.debug("Moving out of the test method: " + new Throwable().getStackTrace()[0].getMethodName());
		Reporter.log("Test method " + new Throwable().getStackTrace()[0].getMethodName() + " is executed successfully");
	}
}
