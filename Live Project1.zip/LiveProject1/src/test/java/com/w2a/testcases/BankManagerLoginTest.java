package com.w2a.testcases;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.SkipException;
import org.testng.annotations.Test;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;

import com.w2a.base.BaseClass;
import com.w2a.utilities.TestUtilities;


public class BankManagerLoginTest extends BaseClass{
	
	@Test
	public void bankManagerLoginTest() throws IOException  {
		
		if (!(TestUtilities.isTestRunnable("bankManagerLoginTest", excel))) {

			throw new SkipException("Skipping the test " + "bankManagerLoginTest".toUpperCase() + "as the Run mode is NO");
		}
	
		log.debug("Inside the  test: " +new Throwable().getStackTrace()[0].getMethodName());
		click("bankManagerLoginButtom_CSS");
		try {
			//verifyEquals("wrong", "right");
		Assert.assertTrue(isElementPresent(By.cssSelector(or.getProperty("addCutomerTab_CSS"))),"Login not successful");
		log.debug("Login is successful");
		
		}catch(NoSuchElementException e) {
			e.printStackTrace();			
		}
		
		log.debug("Test executed: "+new Throwable().getStackTrace()[0].getMethodName());
		Reporter.log("Test method " + new Throwable().getStackTrace()[0].getMethodName()+" is executed successfully");
		}

}
