package com.w2a.utilities;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.Hashtable;
import java.lang.reflect.Method;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.io.FileHandler;
import org.testng.annotations.DataProvider;

import com.w2a.base.BaseClass;

public class TestUtilities extends BaseClass {

	public static String screenshotPath;

	public static void captureScreenshot() {
		File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		Date d = new Date();
		screenshotPath = System.getProperty("user.dir") + "\\Screenshots\\"
				+ d.toString().replace(":", "_").replace(" ", "_") + ".jpg";
		System.out.println(screenshotPath);
		try {
			FileHandler.copy(srcFile, new File(screenshotPath));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// Common Data provider function's code

	@DataProvider(name = "dp")
	public Object[][] getData(Method m) {
		ReadExcelUtility excel = new ReadExcelUtility(
				System.getProperty("user.dir") + "\\src\\test\\resources\\excel\\testdata.xlsx");
		String sheetName = m.getName();
		int row = excel.rowCount(sheetName);
		int col = excel.colCount(sheetName);

		Object[][] data = new Object[row - 1][1];
		Hashtable<String, String> table = null;

		for (int i = 1; i < row; i++) {
			table = new Hashtable<String, String>();
			for (int j = 0; j < col; j++) {
				table.put(excel.getStringData(sheetName, 0, j), excel.getStringData(sheetName, i, j));
			}
			data[i-1][0] = table;
		}
		return data;

	}

	// Returns a boolean value to check if the test is runnable
	public static boolean isTestRunnable(String testName, ReadExcelUtility excel) {

		String sheetName = config.getProperty("testCaseRunModeSheet");
		int rows = excel.rowCount(sheetName);

		for (int rNum = 1; rNum < rows; rNum++) {
			String testCase = excel.getStringData(sheetName, "testID", rNum);

			if (testCase.equalsIgnoreCase(testName)) {

				String runmode = excel.getStringData(sheetName, "runMode", rNum);

				if (runmode.equalsIgnoreCase("Y"))
					return true;
				else
					return false;
			}

		}
		return false;
	}
}
