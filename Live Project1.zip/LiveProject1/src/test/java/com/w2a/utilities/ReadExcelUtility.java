package com.w2a.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.swing.plaf.synth.SynthOptionPaneUI;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcelUtility {

	Workbook workbook;

	public ReadExcelUtility(String filePath) {
		// Create an object of File class to open excel file
		File file = new File(filePath);
		// Create an object of FileInputStream class to read excel file
		try {
			FileInputStream fileInputStream = new FileInputStream(file);
			workbook = new XSSFWorkbook(fileInputStream);

		} catch (IOException e) {
			e.printStackTrace();
			
		}
	}

	public String getStringData(int sheetIndex, int row, int col) {
		return workbook.getSheetAt(sheetIndex).getRow(row).getCell(col).getStringCellValue();
	}

	public String getStringData(String sheetName, int row, int col) {
		return workbook.getSheet(sheetName).getRow(row).getCell(col).getStringCellValue();
	}

	public double getNumericValue(int SheetIndex, int row, int col) {
		return workbook.getSheetAt(SheetIndex).getRow(row).getCell(col).getNumericCellValue();
	}

	public double getNumericValue(String sheetName, int row, int col) {
		return workbook.getSheet(sheetName).getRow(row).getCell(col).getNumericCellValue();
	}

	public int rowCount(String sheetName) {
		int rowCount = (workbook.getSheet(sheetName).getLastRowNum() - workbook.getSheet(sheetName).getFirstRowNum())
				+ 1;
		return rowCount;
	}

	public int rowCount(int sheetIndex) {
		int rowCount = (workbook.getSheetAt(sheetIndex).getLastRowNum()
				- workbook.getSheetAt(sheetIndex).getFirstRowNum()) + 1;
		return rowCount;
	}

	public int colCount(String sheetName) {
		int colCount = workbook.getSheet(sheetName).getRow(1).getLastCellNum();
		return colCount;
	}

	public int colCount(int sheetIndex) {
		int colCount = workbook.getSheetAt(sheetIndex).getRow(1).getLastCellNum();
		return colCount;
	}

	// To use in fetching the status of testcase execution
	public String getStringData(String sheetName, String colName, int rowNUM) {

		for (int i = 0; i < colCount(sheetName); i++) {
			if (colName.equalsIgnoreCase(getStringData(sheetName, 0, i))) {
				return workbook.getSheet(sheetName).getRow(rowNUM).getCell(i).getStringCellValue();
			}
		}
		return null;
	}

}