package com.w2a.base;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.w2a.utilities.ExtentReportManager;
import com.w2a.utilities.ReadExcelUtility;
import com.w2a.utilities.TestUtilities;

public class BaseClass {

	public static WebDriver driver;
	public static Properties config = new Properties();
	public static Properties or = new Properties();
	public static FileInputStream fis;
	// Using Logger.getLogger("devpinoyLogger") we create system level logs
	public static Logger log = Logger.getLogger("devpinoyLogger");
	public static ReadExcelUtility excel = new ReadExcelUtility(
			System.getProperty("user.dir") + "\\src\\test\\resources\\excel\\testdata.xlsx");
	public static WebDriverWait wait;
	public ExtentReports extentReport = ExtentReportManager.getInstance();
	public static ExtentTest extentTest;
	static WebElement dropdown;
	public static String browser;

	@BeforeSuite
	public void setUp() {
		String log4jConfPath = System.getProperty("user.dir") + "\\src\\test\\resources\\properties\\Log4j.properties";
		PropertyConfigurator.configure(log4jConfPath);
		log.debug("\n\n-------->    Setting up the test suite execution     <-----------\n\n");

		if (driver == null) {

			try {
				fis = new FileInputStream(
						System.getProperty("user.dir") + "\\src\\test\\resources\\properties\\" + "Config.properties");
				config.load(fis);
				log.debug("Config file is loaded!!");
			} catch (IOException e) {
				e.printStackTrace();
			}

			try {
				fis = new FileInputStream(
						System.getProperty("user.dir") + "\\src\\test\\resources\\properties\\" + "OR.properties");
				or.load(fis);
				log.debug("OR file is loaded!!");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		if (System.getenv("browser") != null && !System.getenv().isEmpty()) {
			browser = System.getenv("browser");
		} else {
			browser = config.getProperty("browser");
		}
		config.setProperty("browser", browser);
		if (config.getProperty("browser").equals("chrome")) {
			System.setProperty("webdriver.chrome.driver",
					System.getProperty("user.dir") + "\\src\\test\\resources\\executables\\" + "chromedriver.exe");
			driver = new ChromeDriver();
			log.debug("Chrome Launched!!");
		} else if (config.getProperty("browser").equals("firefox")) {
			System.setProperty("webdriver.gecko.driver",
					System.getProperty("user.dir") + "\\src\\test\\resources\\executables\\" + "geckodriver.exe");

			driver = new FirefoxDriver();
			log.debug("firefox Launched!!");
		} else if (config.getProperty("browser").equals("ie")) {

			System.setProperty("webdriver.ie.driver",
					System.getProperty("user.dir") + "\\src\\test\\resources\\executables\\" + "IEDriverServer.exe");
			driver = new InternetExplorerDriver();
			System.out.println("_________________________________________________");
			log.debug("IE Launched!!");
		}

		driver.get(config.getProperty("testsiteurl"));
		log.debug("Navigated to test URL :  " + config.getProperty("testsiteurl"));
		driver.manage().window().maximize();
		log.debug("Window maximized");
		driver.manage().deleteAllCookies();
		log.debug("Cookies deleted");
		driver.manage().timeouts().implicitlyWait(Integer.parseInt(config.getProperty("implicit.wait")),
				TimeUnit.SECONDS);
		wait = new WebDriverWait(driver, 15);

	}

	@AfterSuite
	public void tearDown() {

		if (driver != null) {
			driver.quit();
			log.debug("Browser closed!!");
			log.debug("-------->    End of test Suite execution     <-----------\n\n");
		}
	}

	// Function to check if element is present on a webpage or not
	public boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	// Function to click on webElement
	public static void click(String locator) {

		if (locator.endsWith("_CSS")) {
			driver.findElement(By.cssSelector(or.getProperty(locator))).click();
		} else if (locator.endsWith("_XPATH")) {
			driver.findElement(By.xpath(or.getProperty(locator))).click();
		} else if (locator.endsWith("ID")) {
			driver.findElement(By.id(or.getProperty(locator))).click();
		} else if (locator.endsWith("CLASSNAME")) {
			driver.findElement(By.className(or.getProperty(locator))).click();
		} else if (locator.endsWith("LINKTEXT")) {
			driver.findElement(By.linkText(or.getProperty(locator))).click();
		} else if (locator.endsWith("NAME")) {
			driver.findElement(By.name(or.getProperty(locator))).click();
		} else if (locator.endsWith("PARTIALLINKTEXT")) {
			driver.findElement(By.partialLinkText(or.getProperty(locator))).click();
		} else if (locator.endsWith("TAGNAME")) {
			driver.findElement(By.tagName(or.getProperty(locator))).click();
		}
		extentTest.log(LogStatus.INFO, "Clicking on:  " + or.getProperty(locator));
	}

	// Function to send text to webElement
	public static void type(String locator, String text) {
		if (locator.endsWith("_CSS")) {
			driver.findElement(By.cssSelector(or.getProperty(locator))).sendKeys(text);
		} else if (locator.endsWith("_XPATH")) {
			driver.findElement(By.xpath(or.getProperty(locator))).sendKeys(text);
		} else if (locator.endsWith("ID")) {
			driver.findElement(By.id(or.getProperty(locator))).sendKeys(text);
		} else if (locator.endsWith("CLASSNAME")) {
			driver.findElement(By.className(or.getProperty(locator))).sendKeys(text);
		} else if (locator.endsWith("LINKTEXT")) {
			driver.findElement(By.linkText(or.getProperty(locator))).sendKeys(text);
		} else if (locator.endsWith("NAME")) {
			driver.findElement(By.name(or.getProperty(locator))).sendKeys(text);
		} else if (locator.endsWith("PARTIALLINKTEXT")) {
			driver.findElement(By.partialLinkText(or.getProperty(locator))).sendKeys(text);
		} else if (locator.endsWith("TAGNAME")) {
			driver.findElement(By.tagName(or.getProperty(locator))).sendKeys(text);
		}

		extentTest.log(LogStatus.INFO, "Typing in:  " + or.getProperty(locator) + ", entered value as:  " + text);
	}

	// Function to select a value from dropdown
	public static void select(String locator, String value) {
		if (locator.endsWith("_CSS")) {
			dropdown = driver.findElement(By.cssSelector(or.getProperty(locator)));
		} else if (locator.endsWith("_XPATH")) {
			dropdown = driver.findElement(By.xpath(or.getProperty(locator)));
		} else if (locator.endsWith("ID")) {
			dropdown = driver.findElement(By.id(or.getProperty(locator)));
		} else if (locator.endsWith("CLASSNAME")) {
			dropdown = driver.findElement(By.className(or.getProperty(locator)));
		} else if (locator.endsWith("LINKTEXT")) {
			dropdown = driver.findElement(By.linkText(or.getProperty(locator)));
		} else if (locator.endsWith("NAME")) {
			dropdown = driver.findElement(By.name(or.getProperty(locator)));
		} else if (locator.endsWith("PARTIALLINKTEXT")) {
			dropdown = driver.findElement(By.partialLinkText(or.getProperty(locator)));
		} else if (locator.endsWith("TAGNAME")) {
			dropdown = driver.findElement(By.tagName(or.getProperty(locator)));
		}
		Select select = new Select(dropdown);
		select.selectByVisibleText(value);
		extentTest.log(LogStatus.INFO,
				"Selecting from dropdown:  " + or.getProperty(locator) + ", selected value as:  " + value);
	}

	// Soft Assertion implementation to capture screenshot on failure, attach the
	// screenshot in reportNG and extent Report.
	public static void verifyEquals(String expected, String actual) throws IOException {

		try {

			Assert.assertEquals(actual, expected);

		} catch (Throwable t) {
			System.setProperty("org.uncommons.reportng.escape-output", "false");
			TestUtilities.captureScreenshot();
			// ReportNG
			Reporter.log("<br>" + "Verification failure : " + t.getMessage() + "<br>");
			Reporter.log("<a target=\"_blank\" href=" + TestUtilities.screenshotPath + "><img src="
					+ TestUtilities.screenshotPath + " height=200 width=200></img></a>");
			Reporter.log("<br>");
			Reporter.log("<br>");
			// Extent Reports
			extentTest.log(LogStatus.FAIL, " Verification failed with exception : " + t.getMessage());
			extentTest.log(LogStatus.FAIL, extentTest.addScreenCapture(TestUtilities.screenshotPath));

		}

	}
}
