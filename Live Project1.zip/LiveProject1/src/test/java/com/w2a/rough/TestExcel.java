package com.w2a.rough;

import com.w2a.utilities.ReadExcelUtility;

public class TestExcel {

	public static void main(String[] args) {
		ReadExcelUtility excel= new ReadExcelUtility(System.getProperty("user.dir")+"\\src\\test\\resources\\excel\\testdata.xlsx");
		String sheetName="AddCustomerTest";
		int row= excel.rowCount(sheetName);
		int col= excel.colCount(sheetName);
		System.out.println("rows :"+row+ " cols:   "+col);
		Object[][] data= new Object[row-1][col];
		
		for(int i=1; i<row; i++) {
			for(int j=0; j<col; j++) {
				data[i-1][j]= excel.getStringData(sheetName, i, j);
				System.out.print(data[i-1][j]+"   ");
				
			}
		}

	}

}
